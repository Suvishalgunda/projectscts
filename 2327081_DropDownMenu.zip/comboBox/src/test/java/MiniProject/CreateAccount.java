package MiniProject;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class CreateAccount 
{
	//CONSTRUCTOR
	WebDriver driver;
	public CreateAccount(WebDriver driver)
	{
		this.driver=driver;
	}
	//LOCATORS
	By btn_createaccount_loc=By.xpath("/html/body/div/div[1]/div[1]/div[2]/form/div[2]/div/a/u");
	By txt_name_loc=By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[3]/td[3]/input");
	By txt_mail_loc=By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[7]/td[3]/input[1]");
	By btn_availability_loc=By.className("btn_checkavail");
	By rbtn_login_loc=By.xpath("//*[@id=\"radio_login\"]");
	By txt_password_loc=By.id("newpasswd");
	By txt_confpass_loc=By.id("newpasswd1");
	By chk_select_loc=By.cssSelector("input[type='checkbox']");
	By fiel_day_loc=By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[22]/td[3]/select[1]");
	By fiel_month_loc=By.xpath("//*[@id                    =\"tblcrtac\"]/tbody/tr[22]/td[3]/select[2]");
	By fiel_year_loc=By.xpath("//*[@id=\"tblcrtac\"]/tbody/tr[22]/td[3]/select[3]");
	By fiel_country_loc=By.xpath("//*[@id=\"country\"]");
	
	//ACTION
	public void createAccount()
	{
		driver.findElement(btn_createaccount_loc).click();
	}
	public void setName(String name)
	{   
		driver.findElement(txt_name_loc).sendKeys(name);
		
	}
	public void setMail(String mail)
	{
		driver.findElement(txt_mail_loc).sendKeys(mail);
	}
	public void availButton()
	{
		driver.findElement(btn_availability_loc).click();
	}
	public void clickButton()
	{
		driver.findElement(rbtn_login_loc).click();
	}
	public void setPassword(String password)
	{
		driver.findElement(txt_password_loc).sendKeys(password);
	}
	public void confPass(String conPass)
	{
		driver.findElement(txt_confpass_loc).sendKeys(conPass);
	}
	public void checkBox()
	{
		driver.findElement(chk_select_loc).click();
	}
	public void getDate(String date)
	{
		new Select(driver.findElement(fiel_day_loc)).selectByVisibleText(date);
	}
	public void getMonth(String month)
	{
		new Select(driver.findElement(fiel_month_loc)).selectByVisibleText(month);
	}
	public void getYear(String year)
	{
		new Select(driver.findElement(fiel_year_loc)).selectByVisibleText(year);
	}
	public void selectCountry()
	{
		WebElement country=driver.findElement(fiel_country_loc);
		Select c=new Select(country);
		
		List<WebElement>options=c.getOptions();
		for(WebElement op:options)
		{
			System.out.println(op.getText());
		}
		System.out.println("no.of countries: "+options.size());
		c.selectByVisibleText("India");
		System.out.println("selected country: "+c.getFirstSelectedOption().getText());
		
		
		if(c.getFirstSelectedOption().getText().equals("India"))
		{
			System.out.println("test passed");
		}
		else
		{
			System.out.println("test failed");
		}		
	} 
}
