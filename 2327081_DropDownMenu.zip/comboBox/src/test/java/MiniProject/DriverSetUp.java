package MiniProject;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class DriverSetUp 
{
	public static WebDriver driver;
	public static String baseUrl="https://mail.rediff.com/cgi-bin/login.cgi";
	public static String browserType;
	public static WebDriver driverInstantiate(String browser){
		browserType=browser;
		if(browserType.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
		}
		else if(browserType.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get(baseUrl);		
		return driver;	
		
	}
}
