package TestManagement;
import org.openqa.selenium.WebDriver;

import MiniProject.CreateAccount;
import MiniProject.DriverSetUp;

public class ValidationMain 
{
	static WebDriver driver;
	static CreateAccount ca;

	public static void main(String[] args) throws InterruptedException{  
		driver =DriverSetUp.driverInstantiate("Chrome");
		CreateAccount ca=new CreateAccount(driver);
		ca.createAccount();
		ca.setName("Kamal");
		ca.setMail("kamal23");
		ca.availButton();
		ca.clickButton();
		ca.setPassword("Kamal@1234");
		ca.confPass("Kamal@1234");
		ca.checkBox();
		ca.getDate("20");
		ca.getMonth("JUN");
		ca.getYear("2000");
		ca.selectCountry();	
		driver.quit();
		}
}
