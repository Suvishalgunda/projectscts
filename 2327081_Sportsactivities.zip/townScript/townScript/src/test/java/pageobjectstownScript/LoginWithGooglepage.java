package pageobjectstownScript;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import FactoryTownScript.BaseClassTownScript;


public class LoginWithGooglepage extends BasePage {

	public LoginWithGooglepage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	//Elements
	@FindBy(xpath="/html/body/div[1]/div/div/div/div/a")
	WebElement registeritsfreebutton;
	@FindBy(xpath="//*[@id=\"loginForm\"]/div[4]/a")
	WebElement continueWithGoogle;
	@FindBy(xpath="//*[@id=\"identifierId\"]")
	WebElement emailInputBox;
	@FindBy(xpath="//*[@id=\"identifierNext\"]/div/button/span")
	WebElement nextButton;
	@FindBy(xpath="//*[@id=\"yDmH0d\"]/c-wiz/div/div[2]/div/div/div[1]/form/span/section/div/div/div[1]/div/div[2]/div[2]/div")
	WebElement warningMessage;
	//actions
	public void clickOnRegisterItsFree() 
	{
		registeritsfreebutton.click();
		
	}
	public void continueWithGoogle() 
	{
		continueWithGoogle.click();
	}
	public void enteringInvalidEmail() throws IOException
	{
		BaseClassTownScript Bct = new BaseClassTownScript();
		emailInputBox.sendKeys(Bct.p.getProperty("Email"));
		
	}
	
	public void clickonnextButton() 
	{
		nextButton.click();
	}
	public String  getErrorMessgae() 
	{
		   String errormsg =warningMessage.getText();
		   
		   return errormsg;
	}
	

}
